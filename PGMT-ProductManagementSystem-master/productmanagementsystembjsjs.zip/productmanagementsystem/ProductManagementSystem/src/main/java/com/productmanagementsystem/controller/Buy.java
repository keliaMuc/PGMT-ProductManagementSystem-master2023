package com.productmanagementsystem.controller;

//import com.example.productmanagementsystem.dto.Buydto;
//import com.example.productmanagementsystem.model.Product;
//import com.example.productmanagementsystem.service.BuyService;
//import com.example.productmanagementsystem.service.ProductService;
import com.productmanagementsystem.dto.Buydto;
import com.productmanagementsystem.model.Buyproducts;
import com.productmanagementsystem.model.Product;
import com.productmanagementsystem.services.BuyService;
import com.productmanagementsystem.services.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import javax.validation.Valid;
import java.util.List;


@Controller
public class Buy {

    private final BuyService buyService;
    private final ProductService productService;


    @Autowired
    public Buy(BuyService buyService, ProductService productService)
    {
        this.buyService = buyService;
        this.productService = productService;
    }

//    @GetMapping("/buylistings")
//    public String listbuyproducts(Model model)
//    {
//        List<Buydto> buys = buyService.findAllbuyproducts();
//        model.addAttribute("buys", buys);
//        return "buylist";
//    }
//
//
//
//    @PostMapping("/newbuy")
//    public String saveProductsbought(@ModelAttribute("buys") Buydto buydto,Product product, Model model){
//        model.addAttribute("buys", buydto);
//        model.addAttribute("products",product);
//        buyService.savebuyproducts(buydto);
//        return "redirect:/buylistings";
//    }
//
//    @GetMapping("/newbuy")
//    public String createbuyForm(Model model) {
//        List<Product> products = productService.getAllmodels();
//        model.addAttribute("products", products);
//        model.addAttribute("buys", new Buydto());
//        return "buyproducts";
//    }
//
//
//
//    @GetMapping("/byproduct")
//    public String showBuyProducts(Model model) {
//        List<Buydto> buyProductsList = buyService.findAllbuyproducts();
//        model.addAttribute("buyProductsList", buyProductsList);
//        return "buyproducts";
//    }

    @GetMapping("/buylistings")
    public String listbuyproducts(Model model)
    {
        List<Buydto> bought = buyService.findAllboughtproducts();
        model.addAttribute("bought", bought);
        return "buylist";
    }



    @GetMapping("/newbuy")
    public String createbuyForm(Model model){
        Buydto buydto = new Buydto();
        model.addAttribute("buydto", buydto);
        model.addAttribute("productz",productService.getAllmodels());
//        buyService.savebuyproducts(buydto);
        return "buyproducts";
    }

    @PostMapping("/newbuy")
    public String saveProductsbought(@ModelAttribute("buydto") @Valid Buydto buydto, BindingResult result, Model model) {
        if (result.hasErrors()){
            return "buyproducts";
        }
        buyService.saveBuyProduct(buydto);
        return "redirect:/buylistings";
    }


//
//    @GetMapping("/showFormForAdd")
//    public String showFormForAdd(Model theModel) {
//        Buyproducts theBuyProduct = new Buyproducts();
//        theModel.addAttribute("buyProduct", theBuyProduct);
//        List<Product> theProducts = productService.getAllmodels();
//        theModel.addAttribute("products", theProducts);
//        return "buyproducts";
//    }
//
//    @PostMapping("/saveBuyProduct")
//    public String saveBuyProduct(@ModelAttribute("buyProduct") Buyproducts theBuyProduct) {
//        buyService.saveBuyProduct(theBuyProduct);
//        productService.updateProductStock(theBuyProduct.getProduct().getProduct_id(), theBuyProduct.getQuantity());
//        return "redirect:/buylistings";
//    }



//    @GetMapping("/byproduct")
//    public String showBuyProducts(Model model) {
//        List<Buydto> buyProductsList = buyService.findAllbuyproducts();
//        model.addAttribute("buyProductsList", buyProductsList);
//        return "buyproducts";
//    }

}
