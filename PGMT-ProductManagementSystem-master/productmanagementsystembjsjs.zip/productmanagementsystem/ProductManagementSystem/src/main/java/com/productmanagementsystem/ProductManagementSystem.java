package com.productmanagementsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductManagementSystem {

	public static void main(String[] args) {
		SpringApplication.run(ProductManagementSystem.class, args);
	}

}
