package com.productmanagementsystem.dto;


//import com.example.productmanagementsystem.model.Product;
import com.productmanagementsystem.model.Product;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Component;

//@Entity
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Component


public class Buydto {

    private int buy_id;

    private Product product;

//    private Product buy_product_price;

    private int quantity;

    private int total_price;
}
