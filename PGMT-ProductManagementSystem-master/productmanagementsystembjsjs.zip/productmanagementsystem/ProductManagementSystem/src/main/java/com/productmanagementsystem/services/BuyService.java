package com.productmanagementsystem.services;


//import com.example.productmanagementsystem.dto.Buydto;
import com.productmanagementsystem.dto.Buydto;
import com.productmanagementsystem.model.Buyproducts;

import java.util.List;

public interface BuyService {
//    void savebuyproducts(Buydto buydto);
//    List<Buydto> findAllbuyproducts();

//    Buyproducts saveAll(Buyproducts buying);

//    Buydto saveboughtproducts(Buydto buydto);
public Buyproducts saveBuyProduct(Buyproducts buyProduct);
    List<Buydto> findAllboughtproducts();

}
